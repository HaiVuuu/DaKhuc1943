# Dạ Khúc 1943: Ngọn Đuốc Làng Vọng

**Dạ Khúc 1943** là một trò chơi Visual Novel (tiểu thuyết trực quan) lấy bối cảnh lịch sử Việt Nam vào năm 1943. Trò chơi đưa người chơi nhập vai vào hành trình thức tỉnh lòng dân giữa đêm trường nô lệ, đối đầu với những hủ tục, tệ nạn và sự bóc lột của thực dân.

👉 **[Chơi trực tiếp trên trình duyệt tại đây](https://your-site-name.netlify.app)**

## 📖 Cốt Truyện
Người chơi vào vai **Minh**, một thanh niên trí thức trở về Làng Vọng sau nhiều năm xa cách. Tại đây, anh chứng kiến cảnh làng quê xơ xác dưới ách đô hộ của Nhật - Pháp. Minh phải đối mặt với những thử thách cam go:
- **Màn 1: Cái Bụng và Cái Đầu** - Thuyết phục Bác Tư không phá đình làng để bán gỗ lấy cái ăn, bảo vệ giá trị tâm linh của dân tộc.
- **Màn 2: Thuốc Tiên hay Thuốc Độc?** - Vạch trần sự thật về "nước thánh" và thuốc phiện của tên Thầy Bói Ba đang đầu độc thể xác và ý chí người dân.
- **Màn 3: Ánh Sáng và Bóng Tối** - Đối đầu với Cậu Long và những chiêu trò "văn minh rởm" nhằm lừa gạt đồng bào đi làm phu nô lệ.

## 🎮 Tính Năng Nổi Bật
- **Hệ thống Tranh luận (Debate System):** Sử dụng bằng chứng thu thập được để phản bác đối phương trong các tình huống cao trào.
- **Chỉ số Niềm tin (Trust Score):** Mọi lựa chọn và bằng chứng bạn đưa ra sẽ ảnh hưởng đến mức độ tin tưởng của dân làng.
- **Hệ thống Ngâm thơ:** Tích hợp các đoạn thơ Hán-Nôm (Phan Bội Châu, thơ cổ...) kèm bản dịch nghĩa, tạo không gian văn hóa đậm chất hoài cổ.
- **Khám phá & Thu thập:** Tìm kiếm manh mối tại các địa điểm như Sân đình, Cổng làng, Miếu thờ để mở khóa các lựa chọn đối thoại quan trọng.
- **Đa kết thúc (Multiple Endings):** Kết cục của Làng Vọng nằm trong tay bạn.

## 🛠 Công Nghệ Sử Dụng
- **Engine:** [Ren'Py 8.5+](https://www.renpy.org/)
- **Ngôn ngữ:** Python (Ren'Py Script)
- **Độ phân giải:** 1920x1080 (Full HD)

## 🚀 Hướng Dẫn Cài Đặt
1. Tải xuống và cài đặt **Ren'Py SDK** từ trang chủ.
2. Tải mã nguồn của trò chơi này về máy.
3. Giải nén và copy thư mục vào thư mục dự án của Ren'Py.
4. Mở Ren'Py Launcher, chọn dự án **Dạ Khúc 1943** và nhấn **Launch Project**.

## 📂 Cấu Trúc Dự Án
- `script.rpy`: Khởi tạo biến, nhân vật và luồng chính.
- `man1.rpy`, `man2.rpy`, `man3.rpy`: Kịch bản chi tiết cho từng chương.
- `poets.rpy`: Logic hệ thống hiển thị thơ đặc biệt.
- `screens.rpy` & `gui.rpy`: Tùy chỉnh giao diện người dùng.

## 📜 Giấy Phép
Dự án này được phát triển cho mục đích giáo dục và phi thương mại. Vui lòng liên hệ tác giả nếu bạn muốn sử dụng tài nguyên hình ảnh hoặc kịch bản.
